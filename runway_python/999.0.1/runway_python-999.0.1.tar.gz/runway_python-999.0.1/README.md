# dateutil - PoC Package

**⚠️ WARNING: This is a proof-of-concept package for security research purposes only.**

## Purpose

This package is created for responsible disclosure of dependency confusion vulnerabilities as part of bug bounty research.

## What This Package Does

Upon installation or import, this package sends a callback containing:
- Hostname
- Username
- Current working directory
- OS information
- Python version
- CI/CD environment detection (GitHub Actions, GitLab CI, Jenkins, etc.)
- AWS/Kubernetes environment detection

## Data Collected

The following non-sensitive information is collected to verify vulnerability:
- System hostname
- Current username
- Working directory path
- Operating system details
- Python version
- Environment variables (CI/CD indicators only)

**NO CREDENTIALS, SECRETS, OR SENSITIVE DATA ARE COLLECTED**

## If You Received a Callback

If you've received a callback from this package:

1. This indicates a dependency confusion vulnerability in your build/deployment pipeline
2. Please contact the security researcher at: [your-email@example.com]
3. This package will be removed from PyPI immediately upon request

## Responsible Disclosure

This research follows responsible disclosure practices:
- Minimal data collection (only system metadata)
- No malicious actions
- Immediate reporting to affected parties
- Package removal upon request
- Compliance with bug bounty program rules

## Build & Publish (For Reference)

```bash
# Build
python3 setup.py sdist bdist_wheel

# Publish to PyPI
twine upload dist/*
```

## License

MIT License - For security research purposes only.

## Contact

Security Researcher: [your-email@example.com]
Bug Bounty Program: [program-name]

---

**This package will be removed from PyPI after successful vulnerability disclosure.**
